#include <stdio.h>

int main() {
    float base, altura, area;

   
  
    scanf("%f", &base);

   
    scanf("%f", &altura);

   
    area = 0.5 * base * altura;

   
    printf("%.2f", area);

    return 0;
}
